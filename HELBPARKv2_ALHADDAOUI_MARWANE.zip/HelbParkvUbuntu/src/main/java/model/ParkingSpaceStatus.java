
package model;

/**
 *
 * Enumeration du status de la place
 * FREE quand place libre
 * OCCUPIED quand place occupée
 */
public enum ParkingSpaceStatus {
    
    FREE,
    OCCUPIED;
    
}
